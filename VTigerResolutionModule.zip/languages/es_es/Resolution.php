<?php

$languageStrings = Array(
	'Resolution' => 'Resoluciones',
	'SINGLE_Resolution' => 'Resolución',
	'Resolution ID' => 'Resolución ID',
	
	'LBL_ADD_RECORD' => 'Nueva Resolución',
	'LBL_RECORDS_LIST' => 'Lista de Resoluciones',
	
	'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
	'LBL_RESOLUTION_INFORMATION' => 'Información de Resolución',

	'Resolution' => 'Resolución',
	'Prefix' => 'Prefíjo',
	'Serial' => 'Serial',
	'From' => 'Desde',
	'To' => 'Hasta',
	'Expedition' => 'Expedición',
	'Validity' => 'Válidez',
	'Type' => 'Tipo',
	'Invoices' => 'Facturas',
	'Debit' => 'Débito',
	'Credit' => 'Crédito',
	'Contingency' => 'Contingencia',

	'ModuleFieldLabel' => 'ModuleFieldLabel Text',

	

);
	
?>
