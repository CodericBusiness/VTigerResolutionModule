<?php

$languageStrings = Array(
	'Resolution' => 'Resolution',
	'SINGLE_Resolution' => 'Resolution',
	'ModuleName ID' => 'Resolution ID',
	
	'LBL_ADD_RECORD' => 'Add Resolution',
	'LBL_RECORDS_LIST' => 'Resolution List',
	
	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'LBL_RESOLUTION_INFORMATION' => 'Resolution Information',

	'ModuleFieldLabel' => 'ModuleFieldLabel Text',
);
?>
